const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const Video = require('../models/video');

const db = "mongodb://root:root@ds123976.mlab.com:23976/videoplayer";
mongoose.Promise = global.Promise;
mongoose.connect(db, (err) => {
  if (err) {
    console.log("Error " + err);
  } else {
    console.log("Connection Successful");
  }
});

/* Route to get all the videos list*/
router.get('/videos', (req, res) => {
  console.log('Get request for all videos');
  Video.find({}).exec(function (err, videos) {
    if (err) {
      console.log("Error while retriveing videos");
    } else {
      res.json(videos);
    }
  });
});

/* Route to get a single video by its ID*/
router.get('/videos/:id', (req, res) => {
  console.log('Get request for single video');
  Video.findById(req.params.id).exec(function (err, video) {
    if (err) {
      console.log("Error while retriveing video");
    } else {
      res.json(video);
    }
  });
});

/* Route to add a new video into videos List*/
router.post('/video', (req, res) => {
  console.log('Add a new video request');
  var newVideo = new Video();
  newVideo.title = req.body.title;
  newVideo.url = req.body.url;
  newVideo.category = req.body.category;
  newVideo.description = req.body.description;
  console.log(newVideo);
  newVideo.save(function (err, insertVideo) {
    if (err) {
      console.log('Error while adding new video');
    } else {
      res.json(insertVideo);
    }
  });
});

/* Route to update a video into videos List*/
router.put('/video/:id', (req, res) => {
  console.log('Update a video request');
  Video.findByIdAndUpdate(req.params.id, {
      $set: {
        category: req.body.category,
        title: req.body.title,
        url: req.body.url,
        description: req.body.description
      }
    }, {
      new: true
    },
    function (err, updatedVideo) {
      if (err) {
        res.send('Error while updating video');
      } else {
        res.json(updatedVideo);
      }
    });
});

/* Route to delete single video by its ID*/
router.delete('/video/:id', (req, res) => {
  console.log('Delete request for single video');
  Video.findByIdAndRemove(req.params.id, (err, video) => {
    if (err) {
      res.send("Error while deleting video");
    } else {
      res.json(video);
    }
  });
});

module.exports = router;
