import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-videocenter',
  templateUrl: './videocenter.component.html',
  styleUrls: ['./videocenter.component.css']
})
export class VideocenterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
